package org.bolson.vote;

/**
@deprecated
@see IRNRP
*/
class NamedIRNRP extends IRNRP {
	// Nothing here. Just pass through to underlying implementation in new name.
};
