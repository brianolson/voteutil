package org.bolson.vote;

/**
@deprecated
@see RankedPairs
*/
class NamedRankedPairs extends RankedPairs {
	// Nothing here. Just pass through to underlying implementation in new name.
};
