package org.bolson.vote;

/**
@deprecated
@see Raw
*/
class NamedRaw extends Raw {
	// Nothing here. Just pass through to underlying implementation in new name.
};
