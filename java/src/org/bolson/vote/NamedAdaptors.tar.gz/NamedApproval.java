package org.bolson.vote;

/**
@deprecated
@see Approval
*/
class NamedApproval extends Approval {
	// Nothing here. Just pass through to underlying implementation in new name.
};
