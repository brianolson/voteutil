package org.bolson.vote;

/**
@deprecated
@see IRV
*/
class NamedIRV extends IRV {
	// Nothing here. Just pass through to underlying implementation in new name.
};
