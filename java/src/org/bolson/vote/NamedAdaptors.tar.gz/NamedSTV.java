package org.bolson.vote;

/**
@deprecated
@see STV
*/
class NamedSTV extends STV {
	// Nothing here. Just pass through to underlying implementation in new name.
};
