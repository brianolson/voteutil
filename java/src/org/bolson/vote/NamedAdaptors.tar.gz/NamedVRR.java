package org.bolson.vote;

/**
@deprecated
@see VRR
*/
class NamedVRR extends VRR {
	// Nothing here. Just pass through to underlying implementation in new name.
};
